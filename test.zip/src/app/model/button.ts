export interface Button {
  title:string;
  type:string;
}
