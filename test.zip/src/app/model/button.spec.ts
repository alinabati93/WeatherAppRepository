import { Button } from './button';

describe('Button', () => {
  it('should create an instance', () => {
    expect(new Button()).toBeTruthy();
  });
});
