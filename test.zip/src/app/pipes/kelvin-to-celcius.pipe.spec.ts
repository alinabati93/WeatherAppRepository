import { KelvinToCelciusPipe } from './kelvin-to-celcius.pipe';

describe('KelvinToCelciusPipe', () => {
  it('create an instance', () => {
    const pipe = new KelvinToCelciusPipe();
    expect(pipe).toBeTruthy();
  });
});
